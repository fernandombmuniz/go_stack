/* eslint-disable camelcase */
export default interface ICreateAppointmentDTO {
  provider_id: string;
  date: Date;
}
